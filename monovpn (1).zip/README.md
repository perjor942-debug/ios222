# MonoVPN Desktop Build Instructions

This project is configured to be built as a desktop application using **Electron**.

## Prerequisites
- [Node.js](https://nodejs.org/) installed on your computer.

## How to build the EXE
1. Download the project files to your computer.
2. Open a terminal in the project directory.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Build the portable EXE for Windows:
   ```bash
   npm run electron:build
   ```
5. The built application will be available in the `release/` folder.

## Development
To run the app in development mode on your computer:
```bash
npm run electron:dev
```
