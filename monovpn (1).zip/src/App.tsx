import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Settings as SettingsIcon, Globe, ShieldCheck, ShieldAlert } from 'lucide-react';
import { ConnectionStatus, Server, ConnectionStats } from './types';
import { MOCK_SERVERS } from './constants';
import VPNButton from './components/VPNButton';
import Stats from './components/Stats';
import ServerList from './components/ServerList';
import Settings from './components/Settings';

export default function App() {
  const [status, setStatus] = useState<ConnectionStatus>(ConnectionStatus.DISCONNECTED);
  const [selectedServer, setSelectedServer] = useState<Server>(MOCK_SERVERS[0]);
  const [isServerListOpen, setIsServerListOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [stats, setStats] = useState<ConnectionStats>({
    ip: '127.0.0.1',
    download: 0,
    upload: 0,
    duration: 0,
  });

  // Simulate connection logic
  const handleToggleConnection = useCallback(() => {
    if (status === ConnectionStatus.DISCONNECTED) {
      setStatus(ConnectionStatus.CONNECTING);
      setTimeout(() => {
        setStatus(ConnectionStatus.CONNECTED);
        setStats(prev => ({ ...prev, ip: selectedServer.ip, duration: 0 }));
      }, 2000);
    } else {
      setStatus(ConnectionStatus.DISCONNECTED);
      setStats(prev => ({ ...prev, ip: '127.0.0.1', duration: 0 }));
    }
  }, [status, selectedServer]);

  // Simulate stats update
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (status === ConnectionStatus.CONNECTED) {
      interval = setInterval(() => {
        setStats(prev => ({
          ...prev,
          duration: prev.duration + 1,
          download: prev.download + Math.floor(Math.random() * 1024 * 100),
          upload: prev.upload + Math.floor(Math.random() * 1024 * 20),
        }));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [status]);

  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center p-6 font-sans overflow-hidden">
      {/* Header */}
      <header className="w-full max-w-md flex items-center justify-between mb-12">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
            <ShieldCheck size={20} className="text-black" />
          </div>
          <span className="font-mono font-bold tracking-tighter text-xl">MONO</span>
        </div>
        
        <button 
          onClick={() => setIsSettingsOpen(true)}
          className="p-3 rounded-2xl bg-zinc-900/50 border border-white/5 hover:bg-zinc-800 transition-all"
        >
          <SettingsIcon size={20} className="text-zinc-400" />
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-md flex flex-col items-center justify-between py-8">
        {/* Connection Status Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex items-center gap-2 px-4 py-2 rounded-full bg-zinc-900/50 border border-white/5"
        >
          {status === ConnectionStatus.CONNECTED ? (
            <ShieldCheck size={14} className="text-white" />
          ) : (
            <ShieldAlert size={14} className="text-zinc-600" />
          )}
          <span className="text-[10px] font-mono tracking-widest uppercase text-zinc-400">
            {status === ConnectionStatus.CONNECTED ? 'Tunnel Active' : 'Unprotected'}
          </span>
        </motion.div>

        {/* VPN Button */}
        <VPNButton status={status} onClick={handleToggleConnection} />

        {/* Server Selector */}
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setIsServerListOpen(true)}
          className="w-full p-5 rounded-[24px] bg-zinc-900/50 border border-white/5 flex items-center justify-between group hover:border-white/20 transition-all"
        >
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-xl bg-white/5 group-hover:bg-white/10 transition-colors">
              <Globe size={20} className="text-zinc-400" />
            </div>
            <div className="flex flex-col items-start">
              <span className="text-xs text-zinc-500 uppercase tracking-widest font-mono mb-1">Server Location</span>
              <span className="font-medium">{selectedServer.country}, {selectedServer.city}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-zinc-600">{selectedServer.ping}ms</span>
            <div className="w-1.5 h-1.5 rounded-full bg-zinc-700" />
          </div>
        </motion.button>

        {/* Stats Section */}
        <AnimatePresence>
          {status === ConnectionStatus.CONNECTED && (
            <Stats stats={stats} visible={true} />
          )}
        </AnimatePresence>
      </main>

      {/* Footer / Bottom Info */}
      <footer className="w-full max-w-md mt-8 text-center">
        <p className="text-[10px] text-zinc-700 font-mono tracking-widest uppercase">
          AES-256 Encryption • WireGuard Protocol
        </p>
      </footer>

      {/* Overlays */}
      <ServerList 
        isOpen={isServerListOpen} 
        onClose={() => setIsServerListOpen(false)}
        selectedId={selectedServer.id}
        onSelect={setSelectedServer}
      />
      
      <Settings 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
      />
    </div>
  );
}
