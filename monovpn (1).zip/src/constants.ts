import { Server } from './types';

export const MOCK_SERVERS: Server[] = [
  { id: '1', country: 'United States', city: 'New York', ping: 24, load: 45, ip: '192.168.1.1' },
  { id: '2', country: 'Germany', city: 'Frankfurt', ping: 12, load: 30, ip: '192.168.1.2' },
  { id: '3', country: 'Japan', city: 'Tokyo', ping: 156, load: 80, ip: '192.168.1.3' },
  { id: '4', country: 'United Kingdom', city: 'London', ping: 18, load: 55, ip: '192.168.1.4' },
  { id: '5', country: 'Singapore', city: 'Singapore', ping: 210, load: 15, ip: '192.168.1.5' },
  { id: '6', country: 'Netherlands', city: 'Amsterdam', ping: 15, load: 40, ip: '192.168.1.6' },
];
