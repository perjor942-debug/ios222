export enum ConnectionStatus {
  DISCONNECTED = 'DISCONNECTED',
  CONNECTING = 'CONNECTING',
  CONNECTED = 'CONNECTED',
}

export interface Server {
  id: string;
  country: string;
  city: string;
  ping: number;
  load: number;
  ip: string;
}

export interface ConnectionStats {
  ip: string;
  download: number;
  upload: number;
  duration: number;
}
