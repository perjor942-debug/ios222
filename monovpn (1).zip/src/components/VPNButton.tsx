import { motion } from 'motion/react';
import { Power } from 'lucide-react';
import { ConnectionStatus } from '../types';

interface VPNButtonProps {
  status: ConnectionStatus;
  onClick: () => void;
}

export default function VPNButton({ status, onClick }: VPNButtonProps) {
  const isConnected = status === ConnectionStatus.CONNECTED;
  const isConnecting = status === ConnectionStatus.CONNECTING;

  return (
    <div className="flex flex-col items-center justify-center gap-8">
      <div className="relative">
        {/* Outer Ring Animation */}
        {isConnected && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1.5, opacity: 0 }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeOut" }}
            className="absolute inset-0 rounded-full border border-white/20"
          />
        )}
        
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onClick}
          disabled={isConnecting}
          className={`
            relative z-10 w-48 h-48 rounded-full flex items-center justify-center
            transition-all duration-500 shadow-2xl
            ${isConnected 
              ? 'bg-white text-black' 
              : 'bg-zinc-900 text-white border border-white/10'}
            ${isConnecting ? 'animate-pulse' : ''}
          `}
        >
          <Power size={64} strokeWidth={1.5} />
        </motion.button>
      </div>

      <div className="text-center">
        <motion.p
          key={status}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-sm font-mono tracking-widest uppercase text-zinc-500"
        >
          {status === ConnectionStatus.DISCONNECTED && 'Tap to connect'}
          {status === ConnectionStatus.CONNECTING && 'Establishing tunnel...'}
          {status === ConnectionStatus.CONNECTED && 'Securely connected'}
        </motion.p>
      </div>
    </div>
  );
}
