import { motion } from 'motion/react';
import { ArrowDown, ArrowUp, Clock, Globe } from 'lucide-react';
import { ConnectionStats } from '../types';

interface StatsProps {
  stats: ConnectionStats;
  visible: boolean;
}

export default function Stats({ stats, visible }: StatsProps) {
  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDuration = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
  };

  if (!visible) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="grid grid-cols-2 gap-4 w-full max-w-md"
    >
      <div className="mono-card p-4 flex flex-col gap-1">
        <div className="flex items-center gap-2 text-zinc-500 mb-2">
          <Globe size={14} />
          <span className="text-[10px] uppercase tracking-wider font-mono">IP Address</span>
        </div>
        <span className="font-mono text-sm">{stats.ip}</span>
      </div>

      <div className="mono-card p-4 flex flex-col gap-1">
        <div className="flex items-center gap-2 text-zinc-500 mb-2">
          <Clock size={14} />
          <span className="text-[10px] uppercase tracking-wider font-mono">Duration</span>
        </div>
        <span className="font-mono text-sm">{formatDuration(stats.duration)}</span>
      </div>

      <div className="mono-card p-4 flex flex-col gap-1">
        <div className="flex items-center gap-2 text-zinc-500 mb-2">
          <ArrowDown size={14} />
          <span className="text-[10px] uppercase tracking-wider font-mono">Download</span>
        </div>
        <span className="font-mono text-sm">{formatBytes(stats.download)}</span>
      </div>

      <div className="mono-card p-4 flex flex-col gap-1">
        <div className="flex items-center gap-2 text-zinc-500 mb-2">
          <ArrowUp size={14} />
          <span className="text-[10px] uppercase tracking-wider font-mono">Upload</span>
        </div>
        <span className="font-mono text-sm">{formatBytes(stats.upload)}</span>
      </div>
    </motion.div>
  );
}
