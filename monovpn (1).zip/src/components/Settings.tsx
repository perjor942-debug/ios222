import { motion, AnimatePresence } from 'motion/react';
import { X, Shield, Zap, Bell, Info, Lock, ChevronRight } from 'lucide-react';

interface SettingsProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Settings({ isOpen, onClose }: SettingsProps) {
  const sections = [
    {
      title: 'Security',
      items: [
        { icon: Shield, label: 'Kill Switch', description: 'Block internet if VPN disconnects', toggle: true },
        { icon: Lock, label: 'Protocol', description: 'WireGuard (Recommended)', value: 'WireGuard' },
      ]
    },
    {
      title: 'General',
      items: [
        { icon: Zap, label: 'Auto-Connect', description: 'Connect on startup', toggle: true },
        { icon: Bell, label: 'Notifications', description: 'Status updates', toggle: true },
      ]
    },
    {
      title: 'About',
      items: [
        { icon: Info, label: 'Version', value: '1.0.0 (Build 42)' },
        { icon: ChevronRight, label: 'Privacy Policy' },
        { icon: ChevronRight, label: 'Terms of Service' },
      ]
    }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed inset-y-0 right-0 w-full max-w-md bg-zinc-950 border-l border-white/10 z-50 flex flex-col shadow-2xl"
          >
            <div className="p-6 border-b border-white/5 flex items-center justify-between">
              <h2 className="text-xl font-medium">Settings</h2>
              <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full transition-colors">
                <X size={24} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-8">
              {sections.map((section) => (
                <div key={section.title} className="space-y-4">
                  <h3 className="text-[10px] uppercase tracking-[0.2em] text-zinc-600 font-mono">
                    {section.title}
                  </h3>
                  <div className="space-y-2">
                    {section.items.map((item) => (
                      <div
                        key={item.label}
                        className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-white/10 transition-all cursor-pointer"
                      >
                        <div className="flex items-center gap-4">
                          <div className="p-2 rounded-xl bg-white/5">
                            <item.icon size={20} className="text-zinc-400" />
                          </div>
                          <div className="flex flex-col">
                            <span className="text-sm font-medium">{item.label}</span>
                            {item.description && (
                              <span className="text-xs text-zinc-500">{item.description}</span>
                            )}
                          </div>
                        </div>

                        {item.toggle ? (
                          <div className="w-10 h-6 rounded-full bg-zinc-800 relative p-1 cursor-pointer">
                            <div className="w-4 h-4 rounded-full bg-white" />
                          </div>
                        ) : item.value ? (
                          <span className="text-xs font-mono text-zinc-400">{item.value}</span>
                        ) : (
                          <ChevronRight size={16} className="text-zinc-600" />
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="p-6 border-t border-white/5 text-center">
              <p className="text-[10px] text-zinc-700 font-mono tracking-widest uppercase">
                MonoVPN © 2026 • Secure & Private
              </p>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
