import { motion, AnimatePresence } from 'motion/react';
import { X, Check, SignalHigh, SignalMedium, SignalLow } from 'lucide-react';
import { Server } from '../types';
import { MOCK_SERVERS } from '../constants';

interface ServerListProps {
  isOpen: boolean;
  onClose: () => void;
  selectedId: string;
  onSelect: (server: Server) => void;
}

export default function ServerList({ isOpen, onClose, selectedId, onSelect }: ServerListProps) {
  const getSignalIcon = (ping: number) => {
    if (ping < 30) return <SignalHigh size={16} className="text-white" />;
    if (ping < 100) return <SignalMedium size={16} className="text-zinc-400" />;
    return <SignalLow size={16} className="text-zinc-600" />;
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40"
          />
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed bottom-0 left-0 right-0 h-[70vh] bg-zinc-950 border-t border-white/10 z-50 rounded-t-[32px] flex flex-col"
          >
            <div className="p-6 border-b border-white/5 flex items-center justify-between">
              <h2 className="text-xl font-medium">Select Location</h2>
              <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full transition-colors">
                <X size={24} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {MOCK_SERVERS.map((server) => (
                <motion.button
                  key={server.id}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    onSelect(server);
                    onClose();
                  }}
                  className={`
                    w-full p-4 rounded-2xl flex items-center justify-between transition-all
                    ${selectedId === server.id ? 'bg-white text-black' : 'hover:bg-white/5 text-white'}
                  `}
                >
                  <div className="flex flex-col items-start">
                    <span className="font-medium">{server.country}</span>
                    <span className={`text-xs ${selectedId === server.id ? 'text-black/60' : 'text-zinc-500'}`}>
                      {server.city}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="flex flex-col items-end">
                      <div className="flex items-center gap-1">
                        {getSignalIcon(server.ping)}
                        <span className="text-xs font-mono">{server.ping}ms</span>
                      </div>
                      <span className={`text-[10px] uppercase tracking-tighter ${selectedId === server.id ? 'text-black/60' : 'text-zinc-600'}`}>
                        Load: {server.load}%
                      </span>
                    </div>
                    {selectedId === server.id && <Check size={20} />}
                  </div>
                </motion.button>
              ))}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
